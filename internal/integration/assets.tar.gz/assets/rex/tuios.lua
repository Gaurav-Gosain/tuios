-- tuios for Rex: actions in Rex's command palette, and optional keys, that
-- drive the tuios session shown in the focused Rex pane. The actions are the
-- rows of tuios's own command palette and the person's own [[actions]], read
-- from tuios actions --json each time Rex loads its config.
--
-- Put this file where Rex's init.lua can require it (next to init.lua), then:
--
--   require("tuios").setup{}
--
-- See README.md in this folder for the options and the keys.
--
-- Rex runs Lua 5.1. This file uses nothing newer.

local M = {}

-- M.version is the version of this file. tuios integration status compares it
-- with the one the installed tuios ships.
M.version = 7

-- The Rex block kind that runs a terminal.
local TERMINAL = "com.superlogical.terminal"

-- The default options of setup.
local defaults = {
  -- The tuios program. A name without a slash is looked up in PATH, then in
  -- the folders tuios is installed to (see install_dirs).
  bin = "tuios",
  -- The agent start_agent starts when the action gets no harness.
  harness = "claude",
  -- Keys to bind, by action name. Empty by default: Rex's own keys stay
  -- as they are until you choose some. "suggested" binds M.suggested_keys,
  -- and a table with suggested = true binds them with your own on top.
  keys = {},
}

-- M.mode is the Rex key mode the suggested keys live in, and M.mode_key
-- the one key that enters it. ctrl+cmd+t holds cmd, which a Mac never sends
-- to a program in a terminal, so no key of tuios's or a shell's is taken.
-- It is not a key of Rex for Mac's own (its Mac Actions page) or a macOS
-- shortcut. The mode is entered once: it leaves after one tuios key, and
-- Escape leaves it too. It is exclusive, so a key it does not bind does
-- nothing, and nothing is typed into the terminal by mistake.
M.mode = "tuios"
M.mode_key = "ctrl+cmd+t"

-- M.suggested_keys is the key set setup{ keys = "suggested" } binds, each
-- inside M.mode: one letter after M.mode_key.
M.suggested_keys = {
  tuios_prefix_inbox = M.mode .. "/a",
  tuios_prefix_next_attention = M.mode .. "/j",
  tuios_goto_picker = M.mode .. "/g",
  tuios_prefix_mail = M.mode .. "/m",
  tuios_start_agent = M.mode .. "/n",
  tuios_answer = M.mode .. "/r",
  tuios_switch_session = M.mode .. "/s",
}

-- M.keys_of turns the keys option into the keys to bind, by action name:
-- "suggested" is M.suggested_keys; a table is itself, on top of
-- M.suggested_keys when it holds suggested = true. An action given false is
-- left unbound, so a person can drop one suggested key. The second result
-- is the key that enters M.mode, or nil: M.mode_key with the suggested
-- keys, else the table's mode entry (false for none).
function M.keys_of(keys)
  local out = {}
  local mode_key
  local function copy(from)
    for name, key in pairs(from) do
      if name ~= "suggested" and name ~= "mode" then
        out[name] = key
      end
    end
  end
  if keys == "suggested" then
    copy(M.suggested_keys)
    mode_key = M.mode_key
  elseif type(keys) == "table" then
    if keys.suggested == true then
      copy(M.suggested_keys)
      mode_key = M.mode_key
    end
    if keys.mode ~= nil then
      mode_key = keys.mode
    end
    copy(keys)
  end
  for name, key in pairs(out) do
    if type(key) ~= "string" or key == "" then
      out[name] = nil
    end
  end
  if type(mode_key) ~= "string" or mode_key == "" then
    mode_key = nil
  end
  return out, mode_key
end

local opts = {}

-- M.env is how program reads the environment and the file system. The test
-- replaces it with a stub.
M.env = {
  getenv = os.getenv,
  -- exists says whether a file is there and can be read.
  exists = function(path)
    local f = io.open(path, "r")
    if f == nil then
      return false
    end
    f:close()
    return true
  end,
}

-- install_dirs are the folders tuios is installed to, in the order program
-- looks in them: scripts/install.sh, Homebrew on Apple silicon and on Intel,
-- go install, and Nix. Rex's server starts from the app, so its PATH often
-- has none of the folders a login shell adds.
local function install_dirs()
  local home = M.env.getenv("HOME") or ""
  local dirs = {}
  local function add(d)
    if d ~= nil and d ~= "" then
      dirs[#dirs + 1] = d
    end
  end
  if home ~= "" then
    add(home .. "/.local/bin")
  end
  add("/opt/homebrew/bin")
  add("/usr/local/bin")
  add(M.env.getenv("GOBIN"))
  local gopath = M.env.getenv("GOPATH")
  if gopath ~= nil and gopath ~= "" then
    add(gopath:match("^[^:]+") .. "/bin")
  end
  if home ~= "" then
    add(home .. "/go/bin")
    add(home .. "/.nix-profile/bin")
  end
  add("/etc/profiles/per-user/" .. (M.env.getenv("USER") or "") .. "/bin")
  add("/nix/var/nix/profiles/default/bin")
  add("/run/current-system/sw/bin")
  return dirs
end

-- M.program returns the tuios program to run: bin as given when it has a
-- slash, else the first folder in PATH and then in install_dirs that holds
-- it. When none does it raises an error that names the fix.
function M.program()
  local bin = opts.bin
  if bin:find("/", 1, true) then
    return bin
  end
  local looked = {}
  for d in (M.env.getenv("PATH") or ""):gmatch("[^:]+") do
    if M.env.exists(d .. "/" .. bin) then
      return d .. "/" .. bin
    end
  end
  for _, d in ipairs(install_dirs()) do
    looked[#looked + 1] = d
    if M.env.exists(d .. "/" .. bin) then
      return d .. "/" .. bin
    end
  end
  error(bin .. " is not in Rex's PATH or in " .. table.concat(looked, ", ")
    .. ". Give its full path in init.lua: require(\"tuios\").setup{ bin = \"/full/path/tuios\" }."
    .. " Run 'command -v tuios' in a shell to find it.", 0)
end

-- run runs the tuios CLI with args and returns its result, or raises an
-- error with what it printed.
local function run(args)
  local argv = { M.program() }
  for _, a in ipairs(args) do
    argv[#argv + 1] = a
  end
  local r, err = rex.exec(argv, { timeout = 20 })
  if r == nil then
    error("tuios did not run: " .. tostring(err), 0)
  end
  if not r.ok then
    local why = r.stderr
    if why == nil or why == "" then
      why = r.stdout
    end
    error("tuios " .. args[1] .. " failed: " .. tostring(why), 0)
  end
  return r
end

-- foreground returns the pid of the focused block's foreground process, or
-- nil when the block is not a terminal.
local function foreground(ctx)
  local p = rex.block.call(TERMINAL, "process", { block_id = ctx.block_id })
  if p == nil or p.foreground == nil then
    return nil
  end
  return p.foreground.pid
end

-- M.client_of returns the tuios client in the focused block, as tuios
-- list-clients gives it, or nil and why not. The client is the block's
-- foreground process, so its pid is in tuios list-clients with the session
-- it shows. A block that runs ssh, or a shell, shows no local tuios client.
function M.client_of(ctx)
  local pid = foreground(ctx)
  if pid == nil then
    return nil, "the focused pane is not a terminal"
  end
  local r = run({ "list-clients", "--json" })
  local clients = rex.json.decode(r.stdout)
  if type(clients) ~= "table" then
    return nil, "tuios list-clients gave no list"
  end
  for _, c in ipairs(clients) do
    if c.pid == pid and type(c.session) == "string" and c.session ~= "" then
      return c
    end
  end
  return nil, "The focused Rex pane does not show a tuios session on this machine. Focus a pane that runs tuios, or run tuios in it."
end

-- M.session_of returns the name of the tuios session that the client in the
-- focused block shows, or nil and why not.
function M.session_of(ctx)
  local c, why = M.client_of(ctx)
  if c == nil then
    return nil, why
  end
  return c.session
end

-- session_or_error is session_of for an action: it raises the reason.
local function session_or_error(ctx)
  local s, why = M.session_of(ctx)
  if s == nil then
    error(why, 0)
  end
  return s
end

-- client_action runs a tuios keybinding action in the client that shows the
-- session, as its key would.
local function client_action(name)
  return function(ctx, args)
    local s = session_or_error(ctx)
    run({ "run-command", "-s", s, "Action", name })
    return { session = s }
  end
end

-- fallback are the actions Rex gets when tuios cannot list its own: a tuios
-- older than this file, or none found. Each is a tuios action name and its
-- palette row.
local fallback = {
  { name = "goto_picker", title = "Go to: an agent, session, workspace or pane", category = "Session" },
  { name = "prefix_inbox", title = "Agents: what needs you", category = "Agents" },
  { name = "prefix_mail", title = "Agents: mail for you", category = "Agents" },
  { name = "prefix_next_attention", title = "Agents: go to the oldest waiting", category = "Agents" },
}

-- renamed maps the Rex names of version 2 of this file to the names the list
-- gives the same actions, so a key bound to an old name still binds.
M.renamed = {
  tuios_agents = "tuios_prefix_inbox",
  tuios_mail = "tuios_prefix_mail",
  tuios_next_waiting = "tuios_prefix_next_attention",
}

-- The words title_case leaves in lower case inside a title.
local small = {
  a = true, an = true, the = true, of = true, to = true, on = true, ["in"] = true, ["or"] = true,
  ["and"] = true, ["for"] = true, with = true, by = true, at = true, from = true, as = true, tuios = true,
}

-- M.title_case turns a tuios palette row ("Agents: what needs you") into a
-- title in the style of Rex's own ("Agents: What Needs You"). The first word,
-- and a word next to a colon, is always capitalised.
function M.title_case(s)
  return (s:gsub("()(%a[%w']*)", function(pos, w)
    local first = pos == 1 or s:sub(pos - 2, pos - 1) == ": " or s:sub(pos + #w, pos + #w) == ":"
    if (small[w:lower()] and not first) or w == "tuios" then
      return w
    end
    return w:sub(1, 1):upper() .. w:sub(2)
  end))
end

-- M.list asks tuios for its actions. It returns the decoded answer of tuios
-- actions --json, or nil and why not. It never raises, since setup runs at
-- Rex's config load and an error there would cost the person every line of
-- their init.lua.
function M.list()
  local ok, prog = pcall(M.program)
  if not ok then
    return nil, tostring(prog)
  end
  local rok, r, err = pcall(rex.exec, { prog, "actions", "--json" }, { timeout = 5 })
  if not rok then
    return nil, "tuios did not run: " .. tostring(r)
  end
  if r == nil then
    return nil, "tuios did not run: " .. tostring(err)
  end
  if not r.ok then
    local why = r.stderr
    if why == nil or why == "" then
      why = r.stdout
    end
    return nil, prog .. " actions --json failed, so that tuios is older than this tuios.lua. Update tuios, then run tuios integration install rex. It said: "
      .. tostring(why):gsub("%s+$", "")
  end
  local dok, list = pcall(rex.json.decode, r.stdout or "")
  if not dok or type(list) ~= "table" or type(list.actions) ~= "table" then
    return nil, prog .. " actions --json gave no list of actions"
  end
  return list
end

-- signature is the names of a list of actions, sorted, so tuios_check can
-- tell whether the list Rex loaded is the one tuios gives now.
local function signature(actions)
  local names = {}
  for _, a in ipairs(actions) do
    if type(a) == "table" and type(a.name) == "string" then
      names[#names + 1] = a.name
    end
  end
  table.sort(names)
  return table.concat(names, " ")
end

-- loaded is what setup read: the list's signature, how many actions it
-- defined from it, why it fell back, and the keys it could not bind.
local loaded = {}

-- start_args is the form of tuios_start_agent: a JSON Schema, with the
-- harnesses tuios knows as the choices for harness.
local function start_args(harnesses)
  local harness = { type = "string", description = "The agent to start, as you type it at a shell. Without it: Rex asks, else " .. tostring(opts.harness) .. "." }
  local names = {}
  for _, h in ipairs(harnesses or {}) do
    if type(h) == "table" and type(h.command) == "string" and h.command ~= "" then
      names[#names + 1] = h.command
    end
  end
  if #names > 0 then
    harness.enum = names
  end
  return {
    type = "object",
    properties = {
      harness = harness,
      name = { type = "string", description = "The pane's name, which list-agents shows and -w takes." },
      prompt = { type = "string", description = "The first prompt, typed once the agent is ready." },
      folder = { type = "string", description = "The folder to start in. Without it: Rex asks, else the focused tuios pane's folder." },
      machine = { type = "string", description = "A machine of tuios's [hosts] table to start it on." },
    },
  }
end

-- filled reports whether a form field was given.
local function filled(v)
  return v ~= nil and v ~= ""
end

-- answer_kinds are the Inbox kinds tuios_answer offers: a prompt on a pane
-- that respond can answer. Mail, finished turns and the rest have no prompt.
local answer_kinds = { "approval", "plan", "question" }

-- kind_icon is the rex.ui icon of an Inbox kind.
local kind_icon = { approval = "terminal", plan = "document", question = "person" }

-- M.no_answer is what each no-answer reason of rex.ui.input and rex.ui.pick
-- tells the person. cancelled is not here: the person closed the question,
-- so the action stops and says nothing.
M.no_answer = {
  timeout = "Nobody answered the question in time.",
  no_client = "No Rex app is connected to show the question.",
  unsupported = "No connected Rex app can show a question. Update the Rex app.",
  busy = "Each Rex app already shows another question. Answer that one, then run this again.",
  failed = "Rex could not show the question.",
}

-- unanswered raises the message for a no-answer reason, with the reason in
-- brackets so a script can tell them apart. how names the args that skip the
-- question, for a run with nobody there.
local function unanswered(why, detail, how)
  local msg = M.no_answer[why] or ("Rex gave no answer: " .. tostring(why) .. ".")
  if why == "failed" and detail ~= nil and detail ~= "" then
    msg = msg .. " " .. tostring(detail)
  end
  if how ~= nil and why ~= "busy" then
    msg = msg .. " " .. how
  end
  error(msg .. " (" .. tostring(why) .. ")", 0)
end

-- one_line keeps text from another program to one short line for a title.
local function one_line(s, n)
  s = tostring(s or ""):gsub("[%c]+", " "):gsub("^%s+", ""):gsub("%s+$", "")
  if #s > n then
    s = s:sub(1, n - 3) .. "..."
  end
  return s
end

-- waited says how long ago since, in unix nanoseconds, was: "3m", "2h".
function M.waited(since, now)
  local s = math.max(0, (now or os.time()) - math.floor((tonumber(since) or 0) / 1e9))
  if s < 60 then
    return s .. "s"
  elseif s < 3600 then
    return math.floor(s / 60) .. "m"
  elseif s < 86400 then
    return math.floor(s / 3600) .. "h"
  end
  return math.floor(s / 86400) .. "d"
end

-- json_call runs a tuios command that takes --json and returns its decoded
-- answer. A failure raises tuios's own error line: with --json tuios prints
-- it as the error field on stdout.
local function json_call(argv)
  local full = { M.program() }
  for _, a in ipairs(argv) do
    full[#full + 1] = a
  end
  local r, err = rex.exec(full, { timeout = 20 })
  if r == nil then
    error("tuios did not run: " .. tostring(err), 0)
  end
  local ok, v = pcall(rex.json.decode, r.stdout or "")
  if not r.ok then
    local why = ok and type(v) == "table" and type(v.error) == "string" and v.error or r.stderr
    if why == nil or why == "" then
      why = r.stdout
    end
    error((tostring(why):gsub("%s+$", "")), 0)
  end
  if not ok or type(v) ~= "table" then
    error("tuios " .. argv[1] .. " gave no JSON.", 0)
  end
  return v
end

-- prompt_target is the -w and -s of a waiting item: HOST:SESSION:WINDOW for
-- an item of a linked machine, else the window and its session.
local function prompt_target(item)
  if type(item.host) == "string" and item.host ~= "" then
    return { "-w", item.host .. ":" .. item.session .. ":" .. item.window }
  end
  if type(item.session) == "string" and item.session ~= "" then
    return { "-w", item.window, "-s", item.session }
  end
  return { "-w", item.window }
end

-- with appends the items of more to argv.
local function with(argv, more)
  for _, a in ipairs(more) do
    argv[#argv + 1] = a
  end
  return argv
end

-- M.waiting lists the agents that wait on an answer, oldest first, from
-- tuios list-attention.
function M.waiting()
  local argv = { "list-attention", "--json" }
  for _, k in ipairs(answer_kinds) do
    argv[#argv + 1] = "--kind"
    argv[#argv + 1] = k
  end
  local list = json_call(argv)
  local out = {}
  for _, it in ipairs(type(list.items) == "table" and list.items or {}) do
    if type(it) == "table" and type(it.window) == "string" and it.window ~= "" then
      out[#out + 1] = it
    end
  end
  return out
end

-- M.answer_choices turns a peek into rex.ui.pick items, each id an answer:
-- the numbered options as the prompt shows them when it takes a number,
-- else allow, allow always and deny, then a typed answer when it takes one.
function M.answer_choices(peek)
  local offers = {}
  for _, a in ipairs(type(peek.actions) == "table" and peek.actions or {}) do
    offers[a] = true
  end
  local items = {}
  local options = type(peek.options) == "table" and peek.options or {}
  if offers.choose and #options > 0 then
    for _, o in ipairs(options) do
      items[#items + 1] = { id = "choose:" .. tostring(o.n), title = one_line(o.label, 80), detail = tostring(o.n) }
    end
  else
    if offers.approve then
      items[#items + 1] = { id = "approve", title = "Allow" }
    end
    if offers.approve_always then
      items[#items + 1] = { id = "approve_always", title = "Allow always" }
    end
    if offers.deny then
      items[#items + 1] = { id = "deny", title = "Deny" }
    end
  end
  if offers.text then
    items[#items + 1] = { id = "text", title = "Type an answer", icon = "plus" }
  end
  return items
end

-- answer_how is the hint for a run with nobody there to answer.
local answer_how = "Give the answer as args: window, answer and prompt_id (from tuios peek-prompt --json)."

-- answer is tuios_answer: pick an agent that waits, read its prompt, pick an
-- answer, and send it with tuios respond. It answers only what the person
-- picked: the answer goes with the prompt id of the prompt it showed, so
-- tuios refuses it when the prompt changed in between. With args it asks
-- only what they leave out, and an answer in args needs its prompt_id.
local function answer(ctx, args)
  args = args or {}
  if filled(args.answer) and not (filled(args.window) and filled(args.prompt_id)) then
    error("An answer in args needs the window and the prompt_id that tuios peek-prompt --json prints.", 0)
  end
  local item
  if filled(args.window) then
    item = { window = args.window, session = args.session }
    if args.window:find(":", 1, true) then
      item.session = nil
    end
  else
    local waiting = M.waiting()
    if #waiting == 0 then
      error("No agent waits for an answer.", 0)
    end
    local items = {}
    for i, it in ipairs(waiting) do
      local where = it.session or ""
      if type(it.host) == "string" and it.host ~= "" then
        where = it.host .. ":" .. where
      end
      items[#items + 1] = {
        id = tostring(i),
        title = one_line(it.name ~= nil and it.name ~= "" and it.name or it.window, 60),
        subtitle = one_line(it.summary, 120),
        icon = kind_icon[it.kind],
        detail = where .. "  " .. M.waited(it.since),
      }
    end
    local id, why, detail = rex.ui.pick{
      title = "Answer an agent",
      placeholder = "Filter the agents that wait",
      confirm = "Read the prompt",
      items = items,
    }
    if id == nil then
      if why == "cancelled" then
        return { answered = false, reason = why }
      end
      unanswered(why, detail, answer_how)
    end
    item = waiting[tonumber(id)]
  end
  local target = prompt_target(item)
  local peek = json_call(with({ "peek-prompt", "--json" }, target))
  local who = one_line(peek.name ~= nil and peek.name ~= "" and peek.name or item.window, 40)
  if peek.blocked ~= true then
    error(who .. " no longer waits for an answer. Its state is " .. tostring(peek.state) .. ".", 0)
  end
  if peek.found ~= true or peek.answerable ~= true then
    error(who .. ": " .. one_line(peek.reason, 160) .. ". Answer it in tuios.", 0)
  end
  local action, value, prompt_id = args.answer, args.value, peek.prompt_id
  if filled(action) then
    prompt_id = args.prompt_id
  else
    local question = who .. ": " .. one_line(peek.message ~= "" and peek.message or peek.kind, 100)
    local id, why, detail = rex.ui.pick{
      title = question,
      placeholder = "Filter the answers",
      confirm = "Send",
      items = M.answer_choices(peek),
    }
    if id == nil then
      if why == "cancelled" then
        return { answered = false, reason = why }
      end
      unanswered(why, detail, answer_how)
    end
    if id == "text" then
      local text
      text, why, detail = rex.ui.input{ title = question, placeholder = "Your answer", confirm = "Send" }
      if text == nil then
        if why == "cancelled" then
          return { answered = false, reason = why }
        end
        unanswered(why, detail, answer_how)
      end
      if text == "" then
        return { answered = false, reason = "empty" }
      end
      action, value = "text", text
    else
      action, value = id:match("^(choose):(%d+)$")
      if action == nil then
        action = id
      end
    end
  end
  local argv = { "respond", action }
  if filled(value) then
    argv[#argv + 1] = value
  end
  with(argv, target)
  with(argv, { "--prompt-id", prompt_id, "--json" })
  local ok, res = pcall(json_call, argv)
  if not ok then
    local why = tostring(res)
    if why:find("respond is for the person", 1, true) then
      error("tuios takes answers from Rex only with respond_from_shell = true under [daemon] in tuios's config.toml. Nothing was sent.", 0)
    end
    error(why, 0)
  end
  return { answered = true, window = peek.window, sent = res.sent, state = res.state }
end

-- answer_args is the form of tuios_answer. Each field skips the question
-- that would ask it.
local answer_args = {
  type = "object",
  properties = {
    window = { type = "string", description = "The waiting pane, by name or ID, or HOST:SESSION:WINDOW." },
    session = { type = "string", description = "The pane's session." },
    answer = { type = "string", enum = { "approve", "approve_always", "deny", "choose", "text" }, description = "The answer. Needs window and prompt_id." },
    value = { type = "string", description = "The option number for choose, or the text for text." },
    prompt_id = { type = "string", description = "The prompt id tuios peek-prompt --json prints. tuios refuses the answer when the prompt changed." },
  },
}

-- start_how is the hint for a run of Start an Agent with nobody there.
local start_how = "Give the fields as args: harness, folder, machine and prompt."

-- home_path writes a path under HOME as ~/..., for a short line.
local function home_path(p)
  local home = M.env.getenv("HOME") or ""
  if home ~= "" and p:sub(1, #home) == home and (#p == #home or p:sub(#home + 1, #home + 1) == "/") then
    return "~" .. p:sub(#home + 1)
  end
  return p
end

-- expand_home turns a typed ~ or ~/... into a path under HOME, as a shell
-- would, since start-agent takes the folder as it is.
local function expand_home(p)
  local home = M.env.getenv("HOME") or ""
  if home ~= "" and (p == "~" or p:sub(1, 2) == "~/") then
    return home .. p:sub(2)
  end
  return p
end

-- M.harness_items are the rex.ui.pick items for the harnesses tuios knows,
-- the default first.
function M.harness_items(harnesses, default)
  local items, seen = {}, {}
  local function add(command, name)
    if type(command) == "string" and command ~= "" and not seen[command] then
      seen[command] = true
      items[#items + 1] = { id = command, title = name ~= nil and name ~= "" and name or command, subtitle = command, icon = "terminal" }
    end
  end
  for _, h in ipairs(harnesses or {}) do
    if type(h) == "table" and h.command == default then
      add(h.command, h.name)
    end
  end
  add(default, nil)
  for _, h in ipairs(harnesses or {}) do
    if type(h) == "table" then
      add(h.command, h.name)
    end
  end
  return items
end

-- M.folder_items are the rex.ui.pick items for the folders the session's
-- panes are in: the focused pane's first, then each other once.
function M.folder_items(windows)
  local items, seen = {}, {}
  local list = type(windows) == "table" and type(windows.windows) == "table" and windows.windows or {}
  local function add(w, detail)
    local cwd = type(w) == "table" and w.cwd or nil
    if type(cwd) == "string" and cwd ~= "" and not seen[cwd] then
      seen[cwd] = true
      local short = home_path(cwd)
      items[#items + 1] = { id = cwd, title = short:match("([^/]+)/?$") or short, subtitle = short, icon = "folder", detail = detail }
    end
  end
  for _, w in ipairs(list) do
    if type(w) == "table" and (w.focused == true or w.window_id == windows.focused_window_id) then
      add(w, "focused pane")
    end
  end
  for _, w in ipairs(list) do
    add(w, nil)
  end
  return items
end

-- answer_of reads a rex.ui answer: the id or text, the typed text of an
-- allow_other pick, or nil.
local function answer_of(v)
  if type(v) == "table" then
    return v.text
  end
  return v
end

-- start_agent is tuios_start_agent. It asks for each field the args leave
-- out: the harness, the machine (only when tuios has [hosts]), the folder
-- and the first prompt. It then runs start-agent with --no-wait, which
-- answers once the agent runs, well inside the 30 seconds Rex gives an
-- action, so a failure reaches the person as tuios's own message. The
-- prompt is typed once the agent is ready.
--
-- When no Rex app can show a question (no_client, unsupported), a run with
-- no field opens tuios's own New agent sheet, and a run with fields starts
-- the agent with the defaults for the rest, as a script expects. A field
-- given as an empty string is given: prompt= starts with no prompt.
local function start_agent(ctx, args)
  args = args or {}
  local s = session_or_error(ctx)
  local given = args.harness ~= nil or args.name ~= nil or args.prompt ~= nil or args.folder ~= nil or args.machine ~= nil
  local asking = true
  local stop
  -- ask puts one question, and returns the answer, or nil when there is
  -- none. It sets stop to "cancelled" or "sheet" when the run ends there.
  local function ask(kind, spec)
    if not asking or stop ~= nil then
      return nil
    end
    local v, why, detail
    if kind == "pick" then
      v, why, detail = rex.ui.pick(spec)
    else
      v, why, detail = rex.ui.input(spec)
    end
    if v ~= nil then
      return answer_of(v)
    end
    if why == "cancelled" then
      stop = "cancelled"
    elseif why == "no_client" or why == "unsupported" then
      asking = false
      if not given and loaded.sheet then
        stop = "sheet"
      end
    else
      unanswered(why, detail, start_how)
    end
    return nil
  end
  local harness = args.harness
  if harness == nil then
    local items = M.harness_items(loaded.harnesses, opts.harness)
    harness = ask("pick", {
      title = "Start an agent",
      placeholder = "Filter agents, or type a command",
      confirm = "Use this agent",
      items = items,
      allow_other = true,
    })
  end
  local machine = args.machine
  if machine == nil and asking and stop == nil then
    local ok, hosts = pcall(json_call, { "hosts", "--json" })
    local list = ok and type(hosts.hosts) == "table" and hosts.hosts or {}
    if #list > 0 then
      local items = { { id = "local", title = "This machine", icon = "terminal" } }
      for _, h in ipairs(list) do
        if type(h) == "table" and type(h.host) == "string" and h.host ~= "" and h.host ~= "local" then
          items[#items + 1] = { id = h.host, title = h.host, subtitle = h.addr, icon = "server", detail = h.status }
        end
      end
      machine = ask("pick", { title = "Start it on", placeholder = "Filter machines", items = items })
      if machine == "local" then
        machine = ""
      end
    end
  end
  local folder = args.folder
  if folder == nil and asking and stop == nil then
    if filled(machine) then
      folder = ask("input", { title = "Folder on " .. machine, placeholder = "Empty: the home folder" })
    else
      local ok, windows = pcall(json_call, { "list-windows", "-s", s, "--json" })
      folder = ask("pick", {
        title = "Start it in",
        placeholder = "Filter folders, or type a path",
        items = M.folder_items(ok and windows or nil),
        allow_other = true,
      })
      if filled(folder) then
        folder = expand_home(folder)
      end
    end
  end
  local prompt = args.prompt
  if prompt == nil then
    prompt = ask("input", { title = "First prompt", placeholder = "Empty: no prompt", confirm = "Start the agent" })
  end
  if stop == "cancelled" then
    return { session = s, cancelled = true }
  end
  if stop == "sheet" then
    run({ "run-command", "-s", s, "Action", "new_agent" })
    return { session = s, opened = "the New agent sheet" }
  end
  local target = s
  if filled(machine) then
    target = machine .. ":" .. s
  end
  if not filled(harness) then
    harness = opts.harness
  end
  local argv = { "start-agent", harness, "-s", target, "--focus", "--no-wait", "--print-id" }
  if filled(args.name) then
    argv[#argv + 1] = "--name"
    argv[#argv + 1] = args.name
  end
  if filled(prompt) then
    argv[#argv + 1] = "--prompt"
    argv[#argv + 1] = prompt
  end
  if filled(folder) then
    argv[#argv + 1] = "--cwd"
    argv[#argv + 1] = folder
  end
  local r = run(argv)
  return { session = s, window = (r.stdout or ""):match("^%s*(%S+)") }
end

-- switch_session is tuios_switch_session: pick a tuios session, or type a
-- new name, then show it. When the focused Rex pane shows a tuios client,
-- that client switches to the session, as go-to does. Otherwise a new Rex
-- window attaches it. args.session skips the question.
local function switch_session(ctx, args)
  args = args or {}
  local client = M.client_of(ctx)
  local name, create = args.session, args.create == true
  if not filled(name) then
    local sessions = json_call({ "ls", "--json" })
    local items = {}
    for _, x in ipairs(sessions) do
      if type(x) == "table" and type(x.name) == "string" and x.name ~= "" then
        local n = tonumber(x.window_count) or 0
        local sub = n .. (n == 1 and " pane" or " panes")
        if x.attached == true then
          sub = sub .. ", attached"
        end
        items[#items + 1] = {
          id = x.name, title = x.name, subtitle = sub, icon = "terminal",
          detail = client ~= nil and client.session == x.name and "shown here" or nil,
        }
      end
    end
    local v, why, detail = rex.ui.pick{
      title = client ~= nil and "Switch to a session" or "Attach a session",
      placeholder = "Filter sessions, or type a new name",
      items = items,
      allow_other = true,
    }
    if v == nil then
      if why == "cancelled" then
        return { cancelled = true }
      end
      unanswered(why, detail, "Give the session as an arg: session.")
    end
    if type(v) == "table" then
      name, create = v.text, true
    else
      name = v
    end
    if not filled(name) then
      return { cancelled = true }
    end
  end
  if client ~= nil then
    local argv = { "switch-session", "--client", tostring(client.client_id), name }
    if create then
      argv[#argv + 1] = "--create"
    end
    run(argv)
    return { session = name, switched = true }
  end
  local cmd = { M.program(), "attach", name }
  if create then
    cmd[#cmd + 1] = "--create"
  end
  local w, err = rex.session.new_window{
    layout = rex.layout.block{ flavor = "com.superlogical.terminal.shell", options = { command = cmd } },
  }
  if w == nil then
    error("Rex could not open a window: " .. tostring(err), 0)
  end
  return { session = name, window_id = w.window_id }
end

-- check is tuios_check: which tuios the actions run, its version, the
-- focused pane's session, whether Start an Agent finds its agent, and
-- whether the actions Rex loaded are the ones that tuios lists now.
local function check(ctx, args)
  local out = { tuios = M.program(), lua_version = M.version, actions = loaded.count or 0 }
  local r = run({ "--version" })
  out.version = (r.stdout or ""):match("^%s*([^\n]-)%s*\n") or (r.stdout or ""):match("^%s*(.-)%s*$")
  if loaded.note ~= nil then
    out.actions_note = loaded.note
  else
    local now = M.list()
    if now ~= nil then
      out.actions_current = signature(now.actions) == loaded.signature
    end
  end
  if loaded.keys ~= nil then
    out.keys_note = loaded.keys
  end
  if loaded.config_note ~= nil then
    out.config_note = loaded.config_note
  end
  if loaded.clash ~= nil then
    out.clash_note = loaded.clash
  end
  local ok, s, why = pcall(M.session_of, ctx)
  if ok then
    out.session, out.session_note = s, why
  else
    out.session_note = tostring(s)
  end
  -- Whether Start an Agent would find its agent: the daemon answers for
  -- the PATH start-agent looks on, its own when Rex's lacks it.
  out.agent = opts.harness
  local rok, rr = pcall(run, { "call", "agent-readiness", rex.json.encode({ harnesses = { opts.harness } }) })
  if not rok then
    out.agent_note = tostring(rr)
  else
    local ans = rex.json.decode(rr.stdout)
    for _, a in ipairs((type(ans) == "table" and ans.agents) or {}) do
      out.agent_installed = a.installed == true
    end
    if out.agent_installed == nil then
      out.agent_note = "tuios does not know a harness named " .. tostring(opts.harness)
    end
  end
  return out
end

-- M.rex_name is the Rex action name of a tuios action: tuios_<action>. A
-- user action, user:NAME, is tuios_user_<NAME> with each dash an underscore,
-- since a Rex action name has only lowercase letters, digits and
-- underscores. It is nil for a name Rex cannot take.
function M.rex_name(name)
  local own = name:match("^user:(.+)$")
  local rexname = "tuios_" .. name
  if own ~= nil then
    rexname = "tuios_user_" .. own:gsub("-", "_")
  end
  if rexname:match("^[a-z0-9_]+$") then
    return rexname
  end
  return nil
end

-- M.actions builds the actions setup defines from list, the answer of tuios
-- actions --json, or from the fallback when list is nil: one per tuios
-- action, then Start an Agent and the check. The new_agent action is not
-- one of its own: Start an Agent opens its sheet. The second result names
-- the actions left out because another one has their Rex name, such as
-- user:a-b after user:a_b.
function M.actions(list)
  local rows = fallback
  if list ~= nil then
    rows = list.actions
  end
  local out, seen, clash = {}, { tuios_start_agent = true, tuios_switch_session = true, tuios_answer = true, tuios_check = true }, {}
  for _, a in ipairs(rows) do
    local name = type(a) == "table" and type(a.name) == "string" and a.name or ""
    local rexname = name ~= "" and M.rex_name(name) or nil
    if rexname ~= nil and seen[rexname] then
      clash[#clash + 1] = name
    elseif rexname ~= nil and name ~= "new_agent" then
      seen[rexname] = true
      local title = type(a.title) == "string" and a.title ~= "" and a.title or name
      local category = type(a.category) == "string" and a.category or ""
      -- A user action's label is the person's own words, kept as written.
      if a.user ~= true then
        title = M.title_case(title)
      end
      out[#out + 1] = {
        name = rexname,
        title = "tuios: " .. title,
        description = type(a.description) == "string" and a.description or title,
        keywords = ("tuios " .. category:lower() .. " " .. name:gsub("[_:-]", " ")),
        run = client_action(name),
      }
    end
  end
  out[#out + 1] = {
    name = "tuios_start_agent",
    title = "tuios: Start an Agent",
    description = "Start an agent in a new tuios pane and focus it. Rex asks for the agent, the folder and the first prompt.",
    keywords = "tuios agent start new claude codex",
    args = start_args(list and list.harnesses),
    run = start_agent,
  }
  out[#out + 1] = {
    name = "tuios_switch_session",
    title = "tuios: Switch or Attach a Session",
    description = "Pick a tuios session, or type a new name. The tuios client in the focused pane switches to it, or a new Rex window attaches it.",
    keywords = "tuios session switch attach open new",
    args = {
      type = "object",
      properties = {
        session = { type = "string", description = "The session to show. Without it: Rex asks." },
        create = { type = "boolean", description = "Create the session when it does not exist." },
      },
    },
    run = switch_session,
  }
  out[#out + 1] = {
    name = "tuios_answer",
    title = "tuios: Answer an Agent",
    description = "Pick an agent that waits on an approval or a question, read its prompt, and send the answer you pick.",
    keywords = "tuios agent answer approve allow deny respond question waiting",
    args = answer_args,
    run = answer,
  }
  out[#out + 1] = {
    name = "tuios_check",
    title = "tuios: Check the Rex Integration",
    description = "Say which tuios the actions run, its version, the session of the focused pane, and whether Rex has the actions that tuios lists.",
    keywords = "tuios check doctor integration path",
    run = check,
  }
  return out, clash
end

-- M.setup defines the actions, and binds the keys given in o.keys, such as
-- { tuios_prefix_inbox = "cmd+shift+a" }, or "suggested" (see
-- M.suggested_keys and M.mode). Call it from init.lua, at load.
-- It does not raise when tuios is missing or old: Rex then has the fallback
-- actions, and tuios_check says why. A key for an action Rex does not have
-- is left unbound, and tuios_check names it.
function M.setup(o)
  opts = {}
  for k, v in pairs(defaults) do
    opts[k] = v
  end
  for k, v in pairs(o or {}) do
    opts[k] = v
  end
  loaded = {}
  local list, why = M.list()
  if list == nil then
    loaded.note = why
  else
    loaded.signature = signature(list.actions)
    loaded.harnesses = list.harnesses
    for _, a in ipairs(list.actions) do
      if type(a) == "table" and a.name == "new_agent" then
        loaded.sheet = true
      end
    end
  end
  if list ~= nil and type(list.config_note) == "string" and list.config_note ~= "" then
    loaded.config_note = list.config_note
  end
  local known = {}
  local defined, clash = M.actions(list)
  if #clash > 0 then
    loaded.clash = "left out, since another action has the same Rex name: " .. table.concat(clash, ", ")
  end
  for _, a in ipairs(defined) do
    rex.action{
      name = a.name,
      title = a.title,
      description = a.description,
      category = "tuios",
      keywords = a.keywords,
      args = a.args,
      run = a.run,
    }
    known[a.name] = true
  end
  loaded.count = #defined
  local unbound = {}
  local keys, mode_key = M.keys_of(opts.keys)
  local in_mode = false
  for _, key in pairs(keys) do
    in_mode = in_mode or key:sub(1, #M.mode + 1) == M.mode .. "/"
  end
  if in_mode then
    -- Rex before key modes has no rex.mode; the keys still bind.
    pcall(rex.mode, M.mode, { exclusive = true })
  end
  if mode_key ~= nil then
    local ok, err = pcall(rex.bind, mode_key, "client.mode.enter", { name = M.mode, once = true })
    if not ok then
      unbound[#unbound + 1] = "mode (" .. tostring(err) .. ")"
    end
  end
  for name, key in pairs(keys) do
    local target = name
    if not known[target] and M.renamed[name] ~= nil then
      target = M.renamed[name]
    end
    if not known[target] then
      unbound[#unbound + 1] = tostring(name)
    else
      local ok, err = pcall(rex.bind, key, target)
      if not ok then
        unbound[#unbound + 1] = tostring(name) .. " (" .. tostring(err) .. ")"
      end
    end
  end
  if #unbound > 0 then
    table.sort(unbound)
    loaded.keys = "not bound, since Rex has no such tuios action: " .. table.concat(unbound, ", ")
  end
  return M
end

return M
