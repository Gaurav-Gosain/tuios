# Pane grants: what a pane may do

Every pane holds grants that say what a process in it may do through tuios. The
daemon checks every call from a pane against them before anything runs: the
CLI, a script on the socket, `tuios mcp` and the tmux shim alike. The person's
own shell and client, outside every pane, are held to nothing new.

```sh
tuios pane-grants
tuios pane-grants --json | jq -r '.grants | join(",")'
```

| Grant | What it lets you do |
| --- | --- |
| `read` | Read your own session and your fan group: list, `get-window`, capture, agent state, waits, the event stream, mail |
| `write` | Type into the panes of your own session that hold nothing you do not, and leave mail and stashed files there |
| `mail` | Leave mail with `send-agent-message` in any session, by `-s`/`-w` or `--select`, always as yourself, and list every session's agents (`list-agents --all-sessions`, `--select`), names, harness and state only. Types into nothing |
| `fan` | Write in your fan group and the sessions you launched, and start agents with `fan` and `start-agent`. Close the panes that you started, and the panes that they started, with `close-window`, and wait for them with `wait-for agent-state --select` |
| `respond` | Answer another pane's prompt with `respond`, for the person, and type into a pane waiting on a prompt. You answer for the panes of your own session. With `fan` you also answer in your fan group, and with `admin` in every session |
| `files` | Copy files with `tuios cp`, and see and control your own copies with `tuios transfers` |
| `task` | Add, claim, finish, stage, block and release the task cards of your own session (`tuios task`). You claim only for yourself and change only the card you hold |
| `admin` | Everything else: other sessions, listings across sessions, windows, layouts, options, `kill-session`, `run-command`, `switch-session`, `detach-client`, attach, any task card and `tuios task rm`. Includes `read`, `write`, `mail`, `fan`, `files` and `task`, never `respond` |

Whatever you hold, you can report about your own pane (`set-agent-state`,
`set-agent-meta`, `set-agent-session`, `report-agent-activity`, `report-program-status`,
`agent-mail-notice`, `ask-human`, `request-approval`) and ask what you hold. So `tuios agent-hook` works in every pane.
A report about another pane needs `respond`, with `admin` too, because the
state it sets decides whether that pane waits on a prompt. A process tuios
starts outside every pane, such as a hook, reports for no pane.

The paste buffers hold what the person copied, so they need grants too:
`list-buffers` and `show-buffer` need `read`, `set-buffer` and `delete-buffer`
need `write`, and `paste-buffer` needs both, since what it types into your own
pane comes back to you. Without `admin` a buffer you set is your pane's own,
and you see, read, change and paste only your own buffers: not the person's,
and not another pane's. `set-buffer` makes a buffer with no name, and a `-b`
name that is not yours answers `no_buffer`. A connection restricted to its own session
(`tuios mcp` without `--scope all`) reaches no buffers, since every session
shares them.

The `files` grant reaches the copies that stay near your work. A copy may
start when each end on this machine is inside your pane's folder. That is
the session's worktree when tuios made it, else the folder the pane started
in. A `cd` or an OSC 7 does not move it. Every file the copy reads or writes
here stays inside it, and a link does not lead out. The home folder, the
folders above it and a folder another user owns are never a pane's folder: start the pane in a project
folder or a worktree. A pane without admin starts windows and agents only
inside its folder, and types only into panes whose folder is inside its
own. Each end on a host must be under its home folder, or be its receive folder
(`HOST:`). A copy out of the project into the person's other folders, or into
a host's system folders, needs the person. `files` sees, pauses, resumes,
cancels, answers and clears only the copies your pane started, never the
person's or another pane's. Every copy carries the name of the pane that
started it, whatever the pane holds. A refusal is `forbidden`, and
`tuios cp` exits 4.

With `fan` and without `admin`, `close-window` reaches only the panes that
you started and their own children. Name the window by its id, or by its name.
A child in another session closes by its id. To use its name, add `-s` with
its session. A
pane outside that tree needs `admin`. A pane whose parent is closed is outside
the tree, unless you are the root of its agent chain, so close the deepest
panes first. `wait-for agent-state --select` watches only the panes of your
tree, also when the selector matches more.

`TUIOS_PANE_GRANTS` is what the pane held when its process started;
`tuios pane-grants` is what it holds now.

## Typing into another pane

What you type into a pane runs with that pane's grants. So without `admin`,
typing into any pane but your own (`send-text`, `send-keys`, `run`,
`ask-agent`, `queue`) is refused when the target holds a grant you do not.
Typing into another pane on `needs_input` is refused unless you hold
`respond`, with `admin` too, because keys typed there answer its prompt.
A pane that something other than itself moved off `needs_input` is refused the
same way, because its prompt can still be on the screen. This lasts until the
pane reports for itself, comes to a prompt again, or runs another program.
With `respond`, `send-text`, `send-keys` and `paste-buffer` into a pane on
`needs_input` still need `--allow-blocked`, which says you read the prompt.
A permission prompt is for the person. `queue` waits until the pane is at rest,
so it is not refused for this. From a pane, `send-text` and `send-keys` need
`-w`. Without `respond`, `PREFIX` is refused, and `run-command` may not
type, press keys or run an action. A message you queue is checked against your
grants again when it is typed, and dropped if they no longer cover the
target. Your keys always go to the target's terminal, never to the
window manager.

## A refusal

A call your grants do not cover does nothing and answers `forbidden`, with a
hint naming the grant it needed, what you hold and where that came from:

```
send-text is refused for this pane: writing into the pane's own session needs the write grant
```

That is the person's decision. Do the work inside what you hold, or ask the
person (`tuios ask-human`, or mail to `human`). Do not look for another verb or
process that does the same thing, and do not try to raise your own grants: you
cannot, and trying says the wrong thing about what you are doing. From a pane
without `admin`, a call that names no session means your own session.

## Where grants come from

- `--grants` when the pane was started: `tuios start-agent`, `tuios fan` and
  `tuios new-window` take it.
- Or `tuios set-pane-grants` later.
- Or else the default of `[agents.permissions]` in config.toml: `admin` under
  `mode = "open"` (the default), and the `grants` list under `mode = "strict"`
  (`read`, `write` and `fan` when unset). A change to the file that gives
  panes less applies at once. A change that gives more waits for the person,
  who applies it with `tuios config apply` outside tuios.

A pane can never give more than it holds. A pane without `admin` that starts an
agent without `--grants` gives it its own grants. A pane with `admin` gives the
default, without the grants it does not hold itself. A pane changes only its own
grants unless it holds `admin`, and `admin` cannot give `respond`, so `respond`
comes only from the person.

## A child agent never runs wider than you

An agent that you start through tuios (`start-agent`, `fan`, `new-window`) never
gets a wider permission mode than your own. tuios reads your mode from your
command line. It knows the modes of Claude Code (`--permission-mode`,
`--dangerously-skip-permissions`), Codex (`--sandbox`, `--ask-for-approval`,
`--yolo`), Copilot and Gemini CLI. A child that asks for a wider mode is refused
with `forbidden`, and nothing starts. A child that names no mode starts in your
mode when its default is wider:

```sh
# You run claude --permission-mode plan.
tuios start-agent claude                       # starts claude --permission-mode plan
tuios start-agent codex                        # starts codex --sandbox read-only
tuios start-agent 'claude --permission-mode auto'   # refused
tuios start-agent claude --permission-mode auto     # refused the same way
```

When the work needs more, ask the person. The person starts agents from outside
every pane, and tuios does not hold them.

## Giving a helper less

```sh
tuios start-agent claude --name reviewer --grants read
tuios fan 3 --agent codex --grants read,write 'Add a retry with backoff.'
tuios new-window -s work sandbox --grants read,write
tuios set-pane-grants -w reviewer --grants read
tuios set-pane-grants -w reviewer --reset
```

To drop your own pane's grants before you start an agent in it:

```sh
tuios set-pane-grants --grants read,write && exec claude
```

With `mail` added, the agent still reaches the agents of other sessions, by
mail only. A row of a session you may not read shows only who is there
(`limited: true`), and mail you attach a file to for another session takes
only files in your own folder or your session's stash. `tuios mcp` keeps to
your own session unless it was started with `--scope all`, and `mail` does not
widen that:

```sh
tuios set-pane-grants --grants read,write,mail,task && exec claude
```

A supervisor the person trusts to approve its workers' tool calls is the one
pane that should hold `respond`, and the person gives it:

```sh
tuios set-pane-grants -w supervisor --grants read,write,fan,respond
```

The grants are saved with the window, so a restored pane holds what it held.
`list-windows --json` shows `grants` on every pane given its own.

## How the daemon knows the pane

The daemon places a caller by the kernel's record of its pid. Where the kernel
cannot say (Windows, the BSDs), the CLI presents `TUIOS_PANE_ID` and
`TUIOS_PANE_TOKEN` on every connection, and the daemon holds the connection to
the pane the token proves. You never pass either by hand.

Grants scope accidents and prompt-injected agents that use tuios the ordinary
way. They are not a sandbox: a process that leaves its pane on purpose is not
placed in it. What your process may do to files and other programs is the
operating system's business.
